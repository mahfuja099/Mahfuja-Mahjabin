import HomePage from './home';
import NotFoundPage from './notfound';
import WorkPage from './work';
import ProjectDetailedPage from './project-details';
import Connect from './connect';

export { HomePage, NotFoundPage, WorkPage, ProjectDetailedPage, Connect };
