const words = [
  {
    text: 'Software Development',
    value: 90
  },
  {
    text: 'ReactJS',
    value: 44
  },
  {
    text: 'NodeJS',
    value: 56
  },
  {
    text: 'ExpressJS',
    value: 53
  },
  {
    text: 'React Native',
    value: 36
  },
  {
    text: 'UI/UX Designing',
    value: 73
  },
  {
    text: 'Figma',
    value: 55
  },
  {
    text: 'Freelancing',
    value: 43
  },
  {
    text: 'SRMKZILLA',
    value: 54
  },
  {
    text: 'Heiphen',
    value: 54
  },
  {
    text: 'System Designs',
    value: 46
  },
  {
    text: 'NOSQL',
    value: 56
  },
  {
    text: 'SQL Databases',
    value: 43
  },
  {
    text: 'SRM University',
    value: 55
  },
  {
    text: 'Backend Development',
    value: 66
  },
  {
    text: 'Full Stack Developer',
    value: 53
  },
  {
    text: 'Building Products',
    value: 43
  },
  {
    text: 'Chrome Extensions',
    value: 50
  },
  {
    text: 'MongoDB',
    value: 58
  },
  {
    text: 'SRM CARE',
    value: 50
  },
  {
    text: 'Web Development',
    value: 65
  },
  {
    text: 'App Development',
    value: 50
  },
  {
    text: 'Frontend Development',
    value: 40
  },
  {
    text: 'Resume Reviews',
    value: 55
  },
  {
    text: 'Geek',
    value: 36
  },
  {
    text: 'Coder',
    value: 38
  },
  {
    text: 'Cricket lover',
    value: 43
  },
  {
    text: 'Valorant Player',
    value: 40
  }
];
export default words;
